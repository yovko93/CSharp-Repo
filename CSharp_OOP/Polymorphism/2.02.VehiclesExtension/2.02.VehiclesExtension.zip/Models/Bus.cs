﻿namespace _2._02.VehiclesExtension.Models
{
    public class Bus : Vehicle
    {
        private double fuelConsumptionIncrease = 1.4;
        private double defaultFuelConsumption;

        public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) 
            : base(fuelQuantity, fuelConsumption, tankCapacity)
        {
            this.defaultFuelConsumption = fuelConsumption;
            this.fuelConsumptionIncrease += fuelConsumption;
        }

        //public override double FuelConsumption =>
        //    base.FuelConsumption + FUEL_CONSUMPTION_INCR;

        public override double FuelConsumption =>
            base.FuelConsumption;

        public override string Drive(double distance)
        {
            if (!this.IsEmpty)
            {
                this.FuelConsumption = this.fuelConsumptionIncrease;
            }
            else
            {
                this.FuelConsumption = this.defaultFuelConsumption;
            }

            return base.Drive(distance);
        }

    }
}

﻿namespace _2._02.VehiclesExtension.Models.Contracts
{
    public interface IRefuelable
    {
        void Refuel(double litters);
    }
}

﻿namespace _2._02.VehiclesExtension.Models.Contracts
{
    public interface IDriveable
    {
        string Drive(double distance);

        //void DriveEmpty(double distance);
    }
}

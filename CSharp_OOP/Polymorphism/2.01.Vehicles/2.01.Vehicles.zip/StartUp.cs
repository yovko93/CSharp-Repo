﻿using _2._01.Vehicles.Contracts;
using _2._01.Vehicles.Models;
using System;

using System.Linq;
using System.Transactions;

namespace _2._01.Vehicles
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] carInfo = Console.ReadLine().Split().ToArray();
            string[] truckInfo = Console.ReadLine().Split().ToArray();

            IVehicle car = new Car(double.Parse(carInfo[1]), double.Parse(carInfo[2]));
            IVehicle truck = new Truck(double.Parse(truckInfo[1]), double.Parse(truckInfo[2]));

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split().ToArray();

                string command = input[0];
                string typeVehicle = input[1];

                switch (command)
                {
                    case "Drive":
                        double distance = double.Parse(input[2]);

                        if (typeVehicle == "Car")
                        {
                            car.Drive(distance);
                        }
                        else if (typeVehicle == "Truck")
                        {
                            truck.Drive(distance);
                        }

                        break;

                    case "Refuel":
                        double litters = double.Parse(input[2]);

                        if (typeVehicle == "Car")
                        {
                            car.Refuel(litters);
                        }
                        else if (typeVehicle == "Truck")
                        {
                            truck.Refuel(litters);
                        }

                        break;
                }

            }

            Console.WriteLine($"Car: {Math.Round(car.FuelQuantity, 2):f2}");
            Console.WriteLine($"Truck: {Math.Round(truck.FuelQuantity, 2):f2}");
        }
    }
}

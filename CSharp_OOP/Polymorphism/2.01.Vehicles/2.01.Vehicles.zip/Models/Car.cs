﻿using System;

using _2._01.Vehicles.Contracts;

namespace _2._01.Vehicles.Models
{
    public class Car : IVehicle
    {
        private const double AIR_CONDITIONER = 0.9;

        public Car(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumption { get; private set; }

        public void Drive(double distance)
        {
            double consumption = (this.FuelConsumption + AIR_CONDITIONER) * distance;

            if (this.FuelQuantity >= consumption)
            {
                this.FuelQuantity -= consumption;
                Console.WriteLine($"Car travelled {distance} km");
            }
            else
            {
                Console.WriteLine("Car needs refueling");
            }
        }

        public void Refuel(double litters)
        {
            this.FuelQuantity += litters;
        }
    }
}

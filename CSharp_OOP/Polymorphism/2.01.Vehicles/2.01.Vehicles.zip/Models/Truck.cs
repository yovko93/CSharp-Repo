﻿using System;

using _2._01.Vehicles.Contracts;

namespace _2._01.Vehicles.Models
{
    public class Truck : IVehicle
    {
        private const double AIR_CONDITIONER = 1.6;

        public Truck(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumption { get; private set; }

        public void Drive(double distance)
        {
            double consumption = (this.FuelConsumption + AIR_CONDITIONER) * distance;

            if (this.FuelQuantity >= consumption)
            {
                this.FuelQuantity -= consumption;
                Console.WriteLine($"Truck travelled {distance} km");
            }
            else
            {
                Console.WriteLine("Truck needs refueling");
            }
        }

        public void Refuel(double litters)
        {
            this.FuelQuantity += litters * 0.95;
        }
    }
}

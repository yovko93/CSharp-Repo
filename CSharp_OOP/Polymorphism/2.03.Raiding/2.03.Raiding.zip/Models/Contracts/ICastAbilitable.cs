﻿namespace _2._03.Raiding.Models.Contracts
{
    public interface ICastAbilitable
    {
        string CastAbility();
    }
}

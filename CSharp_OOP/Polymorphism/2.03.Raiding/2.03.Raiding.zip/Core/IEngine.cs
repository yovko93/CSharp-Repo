﻿namespace _2._03.Raiding.Core
{
    public interface IEngine
    {
        void Run();
    }
}

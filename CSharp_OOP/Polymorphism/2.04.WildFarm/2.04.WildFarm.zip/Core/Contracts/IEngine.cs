﻿namespace _2._04.WildFarm.Core.Contracts
{
    public interface IEngine
    {

        void Run();
    }
}

﻿namespace _2._04.WildFarm.Models.Animals.Contracts
{
    public interface ISoundProducable
    {

        string ProduceSound();
    }
}

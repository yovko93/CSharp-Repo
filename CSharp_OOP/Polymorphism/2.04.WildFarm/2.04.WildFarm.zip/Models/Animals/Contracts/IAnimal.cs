﻿namespace _2._04.WildFarm.Models.Animals.Contracts
{
    public interface IAnimal
    {

        string Name { get; }

        double Weight { get; }

    }
}

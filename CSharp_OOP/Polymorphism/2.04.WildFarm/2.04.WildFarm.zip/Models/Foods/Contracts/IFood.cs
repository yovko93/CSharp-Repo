﻿namespace _2._04.WildFarm.Models.Foods.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}

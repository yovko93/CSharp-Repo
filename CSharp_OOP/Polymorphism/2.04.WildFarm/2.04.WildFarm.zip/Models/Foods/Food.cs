﻿using _2._04.WildFarm.Models.Foods.Contracts;

namespace _2._04.WildFarm.Models.Foods
{
    public abstract class Food : IFood
    {
        protected Food(int quantity)
        {
            this.Quantity = quantity;
        }

        public int Quantity { get; }
    }
}

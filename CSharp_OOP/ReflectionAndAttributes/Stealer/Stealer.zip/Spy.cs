﻿using System;
using System.Linq;
using System.Text;
using System.Reflection;

namespace Stealer
{
    public class Spy
    {
        public Spy()
        {

        }


        public string StealFieldInfo(string nameOfTheClass, params string[] fieldsToInvestigate)
        {
            StringBuilder sb = new StringBuilder();
            
            sb.AppendLine($"Class under investigation: {nameOfTheClass}");

            Type classType = Type.GetType(nameOfTheClass);

            FieldInfo[] classFields = classType.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance);

            Object classInstance = Activator.CreateInstance(classType, new object[] { });

            foreach (FieldInfo field in classFields.Where(f => fieldsToInvestigate.Contains(f.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }

            return sb.ToString().Trim();
        }
    }
}

﻿using _2._05.FootballTeamGenerator.Core;
using System;

namespace _2._05.FootballTeamGenerator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}

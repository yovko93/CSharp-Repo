﻿using System;

namespace Farm
{
    class Cat : Animal
    {

        public void Meow()
        {
            Console.WriteLine("meowing...");
        }
    }
}

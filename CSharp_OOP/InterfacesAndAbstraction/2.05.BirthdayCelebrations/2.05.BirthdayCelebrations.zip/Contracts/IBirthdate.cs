﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2._05.BirthdayCelebrations.Contracts
{
    public interface IBirthdate
    {
        public string Birthdate { get; set; }
    }
}

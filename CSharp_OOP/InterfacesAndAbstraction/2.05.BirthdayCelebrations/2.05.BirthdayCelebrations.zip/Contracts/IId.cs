﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2._05.BirthdayCelebrations.Contracts
{
    interface IId
    {
        public string Id { get; set; }
    }
}

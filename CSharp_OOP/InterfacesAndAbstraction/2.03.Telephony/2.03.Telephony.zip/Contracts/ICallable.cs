﻿namespace _2._03.Telephony.Contracts
{
    public interface ICallable
    {
        string Call(string phoneNumber);
    }
}

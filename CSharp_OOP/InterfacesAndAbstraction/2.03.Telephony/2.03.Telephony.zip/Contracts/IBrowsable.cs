﻿namespace _2._03.Telephony.Contracts
{
    public interface IBrowsable
    {
        string Browse(string url);
    }
}

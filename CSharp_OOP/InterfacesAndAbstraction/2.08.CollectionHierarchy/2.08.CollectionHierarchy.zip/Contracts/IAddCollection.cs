﻿namespace _2._08.CollectionHierarchy.Contracts
{
    public interface IAddCollection<T>
    {
        int Add(T item);
    }
}

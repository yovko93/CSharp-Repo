﻿using _2._08.CollectionHierarchy.Controllers;
using System;

namespace _2._08.CollectionHierarchy
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}

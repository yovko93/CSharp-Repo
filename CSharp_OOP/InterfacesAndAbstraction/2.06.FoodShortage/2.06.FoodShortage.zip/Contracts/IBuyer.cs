﻿namespace _2._06.FoodShortage.Contracts
{
    public interface IBuyer
    {
        public int Food { get; }

        public void BuyFood();
    }
}

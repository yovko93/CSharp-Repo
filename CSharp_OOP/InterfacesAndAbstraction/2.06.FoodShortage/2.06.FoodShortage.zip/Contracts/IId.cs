﻿namespace _2._06.FoodShortage.Contracts
{
    interface IId
    {
        public string Id { get; set; }
    }
}

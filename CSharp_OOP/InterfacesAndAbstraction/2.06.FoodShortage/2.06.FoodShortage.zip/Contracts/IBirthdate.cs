﻿namespace _2._06.FoodShortage.Contracts
{
    public interface IBirthdate
    {
        public string Birthdate { get; set; }
    }
}

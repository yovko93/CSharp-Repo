﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2._04.BorderControl.Contracts
{
    public interface IId
    {
        public string Id { get; }
    }
}

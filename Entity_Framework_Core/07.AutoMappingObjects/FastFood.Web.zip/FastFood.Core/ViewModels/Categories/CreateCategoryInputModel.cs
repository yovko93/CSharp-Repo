﻿namespace FastFood.Core.ViewModels.Categories
{
    public class CreateCategoryInputModel
    {
        public string CategoryName { get; set; }
    }
}

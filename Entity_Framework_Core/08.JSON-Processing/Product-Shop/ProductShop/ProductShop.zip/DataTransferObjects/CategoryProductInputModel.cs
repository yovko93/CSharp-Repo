﻿namespace ProductShop.DataTransferObjects
{
    public class CategoryProductInputModel
    {
        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }
}
